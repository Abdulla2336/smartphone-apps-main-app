package com.example.musicinfoapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Genre click listeners
        findViewById<LinearLayout>(R.id.btnPop).setOnClickListener { openGenreDetail("Pop") }
        findViewById<LinearLayout>(R.id.btnRock).setOnClickListener { openGenreDetail("Rock") }
        findViewById<LinearLayout>(R.id.btnJazz).setOnClickListener { openGenreDetail("Jazz") }
        findViewById<LinearLayout>(R.id.btnHipHop).setOnClickListener { openGenreDetail("Hip-Hop") }
        findViewById<LinearLayout>(R.id.btnClassical).setOnClickListener { openGenreDetail("Classical") }
        findViewById<LinearLayout>(R.id.btnEDM).setOnClickListener { openGenreDetail("EDM") }
        findViewById<LinearLayout>(R.id.btnReggae).setOnClickListener { openGenreDetail("Reggae") }
        findViewById<LinearLayout>(R.id.btnCountry).setOnClickListener { openGenreDetail("Country") }
        findViewById<LinearLayout>(R.id.btnFunk).setOnClickListener { openGenreDetail("Funk") }
        findViewById<LinearLayout>(R.id.btnMetal).setOnClickListener { openGenreDetail("Metal") }
        findViewById<LinearLayout>(R.id.btnBlues).setOnClickListener { openGenreDetail("Blues") }
        findViewById<LinearLayout>(R.id.btnSoul).setOnClickListener { openGenreDetail("Soul") }

        // Modal Info
        findViewById<Button>(R.id.btnInfo).setOnClickListener {
            val dialogView = layoutInflater.inflate(R.layout.dialog_info, null)

            val dialog = android.app.AlertDialog.Builder(this)
                .setView(dialogView)
                .create()

            dialogView.findViewById<Button>(R.id.btnClose).setOnClickListener {
                dialog.dismiss()
            }

            dialog.show()
        }
    }

    private fun openGenreDetail(genreName: String) {
        val intent = Intent(this, Detail::class.java)
        intent.putExtra("genre_name", genreName)
        startActivity(intent)
    }
}
