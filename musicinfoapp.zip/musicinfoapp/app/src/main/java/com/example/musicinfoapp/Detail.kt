package com.example.musicinfoapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.musicinfoapp.databinding.ActivityDetailBinding

class Detail : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val genreName = intent.getStringExtra("genre_name") ?: "Unknown Genre"
        binding.txtGenreName.text = genreName

        when (genreName) {
            "Pop" -> {
                binding.genreImage.setImageResource(R.drawable.pop)
                binding.txtGenreDesc.text = "Pop music is made to be catchy, radio-friendly, and appealing to a broad audience. It blends elements from many genres including rock, dance, and R&B."
                binding.txtArtists.text = "🎤 Famous Artists:\n• Taylor Swift\n• Ariana Grande\n• Ed Sheeran\n• Justin Bieber"
                binding.txtFeatures.text = "🎵 Key Features:\n• Catchy melodies\n• Repetitive chorus\n• Polished production"
                binding.txtSubgenres.text = "🎶 Subgenres:\nSynth-pop, Teen Pop, Dance Pop"
                binding.txtInstruments.text = "🎧 Popular Instruments:\nSynthesizer, Keyboard, Drum Machine, Vocals"
                binding.txtAlbums.text = "⭐ Suggested Albums:\n• 1989 – Taylor Swift\n• Future Nostalgia – Dua Lipa"
            }

            "Rock" -> {
                binding.genreImage.setImageResource(R.drawable.rock)
                binding.txtGenreDesc.text = "Rock emerged in the 1950s and has remained one of the most influential genres. It's known for its bold energy, electric guitars, and powerful vocals."
                binding.txtArtists.text = "🎤 Famous Artists:\n• Queen\n• Nirvana\n• Foo Fighters\n• The Beatles"
                binding.txtFeatures.text = "🎵 Key Features:\n• Loud guitars\n• Strong beats\n• Expressive vocals"
                binding.txtSubgenres.text = "🎶 Subgenres:\nHard Rock, Punk Rock, Indie Rock"
                binding.txtInstruments.text = "🎸 Popular Instruments:\nElectric Guitar, Bass, Drums, Synthesizers"
                binding.txtAlbums.text = "⭐ Suggested Albums:\n• Nevermind – Nirvana\n• A Night at the Opera – Queen"
            }

            "Jazz" -> {
                binding.genreImage.setImageResource(R.drawable.jazz)
                binding.txtGenreDesc.text = "Jazz is an expressive genre born in the early 20th century in New Orleans. Known for its improvisational style, it emphasizes swing rhythms and rich harmonies."
                binding.txtArtists.text = "🎤 Famous Artists:\n• Miles Davis\n• John Coltrane\n• Ella Fitzgerald\n• Louis Armstrong"
                binding.txtFeatures.text = "🎵 Key Features:\n• Improvisation\n• Swing rhythm\n• Blue notes"
                binding.txtSubgenres.text = "🎶 Subgenres:\nBebop, Smooth Jazz, Free Jazz"
                binding.txtInstruments.text = "🎺 Popular Instruments:\nSaxophone, Trumpet, Piano"
                binding.txtAlbums.text = "⭐ Suggested Albums:\n• Kind of Blue – Miles Davis"
            }

            "Hip-Hop" -> {
                binding.genreImage.setImageResource(R.drawable.hiphop)
                binding.txtGenreDesc.text = "Hip-Hop is more than just music — it's a culture. It includes rapping (MCing), DJing, graffiti art, and breakdancing. Lyrics often address real-world issues."
                binding.txtArtists.text = "🎤 Famous Artists:\n• Tupac\n• Eminem\n• Kendrick Lamar\n• Nicki Minaj"
                binding.txtFeatures.text = "🎵 Key Features:\n• Rap lyrics\n• Sampling\n• Beatboxing"
                binding.txtSubgenres.text = "🎶 Subgenres:\nTrap, Boom Bap, Conscious Hip-Hop"
                binding.txtInstruments.text = "🎧 Popular Instruments:\nDrum machine, Synths, Sampler"
                binding.txtAlbums.text = "⭐ Suggested Albums:\n• To Pimp a Butterfly – Kendrick Lamar"
            }

            "Classical" -> {
                binding.genreImage.setImageResource(R.drawable.classical)
                binding.txtGenreDesc.text = "Classical music spans centuries and includes orchestral, chamber, and solo works. It's known for its complexity, structure, and emotional depth."
                binding.txtArtists.text = "🎼 Famous Composers:\n• Mozart\n• Beethoven\n• Bach\n• Tchaikovsky"
                binding.txtFeatures.text = "🎵 Key Features:\n• Orchestration\n• Harmonic complexity\n• Formal structure"
                binding.txtSubgenres.text = "🎶 Periods:\nBaroque, Classical, Romantic, Modern"
                binding.txtInstruments.text = "🎻 Popular Instruments:\nViolin, Piano, Cello, Flute"
                binding.txtAlbums.text = "⭐ Suggested Works:\n• Symphony No. 9 – Beethoven"
            }

            "EDM" -> {
                binding.genreImage.setImageResource(R.drawable.edm)
                binding.txtGenreDesc.text = "Electronic Dance Music is built for clubs and festivals. With pulsating beats and build-up drops, EDM creates a high-energy listening experience."
                binding.txtArtists.text = "🎤 Famous Artists:\n• Calvin Harris\n• David Guetta\n• Marshmello\n• Avicii"
                binding.txtFeatures.text = "🎵 Key Features:\n• Synthesized beats\n• Drops\n• Loops"
                binding.txtSubgenres.text = "🎶 Subgenres:\nHouse, Trance, Dubstep, Techno"
                binding.txtInstruments.text = "🎧 Popular Instruments:\nDAWs, Drum Machines, MIDI controllers"
                binding.txtAlbums.text = "⭐ Suggested Albums:\n• True – Avicii"
            }

            "Reggae" -> {
                binding.genreImage.setImageResource(R.drawable.reggae)
                binding.txtGenreDesc.text = "Reggae originated in Jamaica in the late 1960s. Known for its off-beat rhythms and socially conscious lyrics, reggae promotes peace and unity."
                binding.txtArtists.text = "🎤 Famous Artists:\n• Bob Marley\n• Peter Tosh\n• Jimmy Cliff"
                binding.txtFeatures.text = "🎵 Key Features:\n• Off-beat rhythm\n• Laid-back groove"
                binding.txtSubgenres.text = "🎶 Subgenres:\nRoots Reggae, Dancehall, Dub"
                binding.txtInstruments.text = "🥁 Popular Instruments:\nBass, Drums, Rhythm Guitar, Organ"
                binding.txtAlbums.text = "⭐ Suggested Albums:\n• Exodus – Bob Marley"
            }

            "Country" -> {
                binding.genreImage.setImageResource(R.drawable.country)
                binding.txtGenreDesc.text = "Country music tells personal and emotional stories, often set against a backdrop of rural life. It includes heartfelt lyrics and string instruments."
                binding.txtArtists.text = "🎤 Famous Artists:\n• Johnny Cash\n• Dolly Parton\n• Luke Bryan"
                binding.txtFeatures.text = "🎵 Key Features:\n• Storytelling lyrics\n• Acoustic sound"
                binding.txtSubgenres.text = "🎶 Subgenres:\nBluegrass, Country Pop, Honky Tonk"
                binding.txtInstruments.text = "🎸 Popular Instruments:\nAcoustic Guitar, Banjo, Fiddle"
                binding.txtAlbums.text = "⭐ Suggested Albums:\n• Jolene – Dolly Parton"
            }

            "Funk" -> {
                binding.genreImage.setImageResource(R.drawable.funk)
                binding.txtGenreDesc.text = "Funk is a rhythmic, danceable style of music that emerged in the 1960s. It’s driven by bass lines and groove."
                binding.txtArtists.text = "🎤 Famous Artists:\n• James Brown\n• Prince\n• Parliament-Funkadelic"
                binding.txtFeatures.text = "🎵 Key Features:\n• Slap bass\n• Syncopation\n• Groove"
                binding.txtSubgenres.text = "🎶 Subgenres:\nP-Funk, Electro-funk"
                binding.txtInstruments.text = "🎷 Popular Instruments:\nBass Guitar, Horns, Drums"
                binding.txtAlbums.text = "⭐ Suggested Albums:\n• Sign o’ the Times – Prince"
            }

            "Metal" -> {
                binding.genreImage.setImageResource(R.drawable.metal)
                binding.txtGenreDesc.text = "Metal is intense, aggressive, and loud. It features distorted guitar riffs, fast drumming, and themes of rebellion or power."
                binding.txtArtists.text = "🎤 Famous Artists:\n• Metallica\n• Iron Maiden\n• Slipknot"
                binding.txtFeatures.text = "🎵 Key Features:\n• Distortion\n• Power chords\n• Double bass drumming"
                binding.txtSubgenres.text = "🎶 Subgenres:\nHeavy Metal, Thrash Metal, Death Metal"
                binding.txtInstruments.text = "🥁 Popular Instruments:\nElectric Guitar, Drums, Bass"
                binding.txtAlbums.text = "⭐ Suggested Albums:\n• Master of Puppets – Metallica"
            }

            "Blues" -> {
                binding.genreImage.setImageResource(R.drawable.blues)
                binding.txtGenreDesc.text = "Blues music originated in the American South and reflects emotional struggle and resilience. It’s deeply rooted in African-American history."
                binding.txtArtists.text = "🎤 Famous Artists:\n• B.B. King\n• Muddy Waters\n• Robert Johnson"
                binding.txtFeatures.text = "🎵 Key Features:\n• 12-bar progression\n• Emotional vocals"
                binding.txtSubgenres.text = "🎶 Subgenres:\nDelta Blues, Chicago Blues"
                binding.txtInstruments.text = "🎸 Popular Instruments:\nSlide Guitar, Harmonica, Piano"
                binding.txtAlbums.text = "⭐ Suggested Albums:\n• Live at the Regal – B.B. King"
            }

            "Soul" -> {
                binding.genreImage.setImageResource(R.drawable.soul)
                binding.txtGenreDesc.text = "Soul music blends gospel, jazz, and R&B, emphasizing emotion and vocal expression. It was a key part of 1960s Black culture."
                binding.txtArtists.text = "🎤 Famous Artists:\n• Aretha Franklin\n• Marvin Gaye\n• Otis Redding"
                binding.txtFeatures.text = "🎵 Key Features:\n• Emotional delivery\n• Gospel influence"
                binding.txtSubgenres.text = "🎶 Subgenres:\nNeo-Soul, Motown"
                binding.txtInstruments.text = "🎹 Popular Instruments:\nOrgan, Bass, Vocals"
                binding.txtAlbums.text = "⭐ Suggested Albums:\n• What's Going On – Marvin Gaye"
            }

            else -> {
                binding.genreImage.setImageResource(R.drawable.ic_launcher_foreground)
                binding.txtGenreDesc.text = "No details available for this genre."
                binding.txtArtists.text = ""
                binding.txtFeatures.text = ""
                binding.txtSubgenres.text = ""
                binding.txtInstruments.text = ""
                binding.txtAlbums.text = ""
            }
        }

        // ✅ Back button logic
        binding.btnBack.setOnClickListener {
            finish() // closes DetailActivity and goes back to MainActivity
        }
    }
}
